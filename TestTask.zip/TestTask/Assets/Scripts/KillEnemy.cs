﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KillEnemy : MonoBehaviour
{
    [SerializeField]
    MakeTower _tower;
    [SerializeField]
    private GameObject bulletPrefab;
    [SerializeField]
    private Transform Shooter;

    private GameObject Target;

    private float range = 400f;
    private int FirePower = 1;
    public float FireRate = 1f;
    public float FireCountdown = 0f;
    public string EnemyTag = "Enemy";
    
    
   
    // Start is called before the first frame update
    void Start()
    {
        FireRate = _tower.Return_Tower_Speed();
        FirePower = _tower.Return_Tower_Power();
        InvokeRepeating("UpdateTarget", 0f, 0.5f);
    }

    // Update is called once per frame
    void UpdateTarget()
    {
        GameObject[] Enemies = GameObject.FindGameObjectsWithTag(EnemyTag);
        float ShorttestDistance = Mathf.Infinity;
        GameObject NearestEnemy = null;
        foreach(GameObject enemy in Enemies)
        {
            float DistanceToEnemy = Vector3.Distance(transform.position, enemy.transform.position);
            if (ShorttestDistance > DistanceToEnemy)
            {
                ShorttestDistance = DistanceToEnemy;
                NearestEnemy = enemy;
            }
        }
        
        if (NearestEnemy != null && ShorttestDistance <= range)
        {
            Target = NearestEnemy;
        }
        else
        {
            Target = null;
        }
    }
    void Update()
    {
        FireRate = _tower.Return_Tower_Speed();
        FirePower = _tower.Return_Tower_Power();
        if (Target == null) return;
        Vector3 Direction = Target.transform.position - transform.position;
        Quaternion LookRotation = Quaternion.LookRotation(Direction);
        Vector3 Rotation = LookRotation.eulerAngles;
        transform.rotation = Quaternion.Euler(0f,0f,Rotation.y);
       if(FireCountdown<=0f)
        {
            FireCountdown = 1/FireRate;
            Shoot();
        }
        FireCountdown -= Time.deltaTime;
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, range);
    }
    public void Shoot()
    {
        GameObject bulletGO=(GameObject)Instantiate(bulletPrefab, Shooter.position, Shooter.rotation);
        Bullet bullet = bulletGO.GetComponent<Bullet>();
        if (bullet != null)
        {
            bullet.Get_Target(Target,FirePower);
        }
    }
}
