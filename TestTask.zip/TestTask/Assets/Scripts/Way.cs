﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Way : MonoBehaviour
{
    public int Count_Of_Child;
    public static Transform[] points;
    private void Awake()
    {
        Count_Of_Child = transform.childCount;
        points = new Transform[transform.childCount];
        for(int i = 0; i < points.Length; i++)
        {
            points[i] = transform.GetChild(i);
        }
    }
}
