﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartofGame : MonoBehaviour
{
    [SerializeField]
    GameObject[] ForDisable;
    [SerializeField]
    GameObject uiStart;
    [SerializeField]
    GameObject[] ForEnable;
    private bool canWeStart = false ;
   

    // Start is called before the first frame update
    private void Awake()
    {
        foreach (GameObject obj in ForDisable)
        {
            obj.SetActive(false);  
        }
        uiStart.SetActive(true);
    }
    private void Update()
    {
        if (canWeStart)
        {
            foreach (GameObject obj in ForEnable)
            {
                obj.SetActive(true);
                canWeStart = false;
            }
            uiStart.SetActive(false);
            gameObject.SetActive(false);
        }
      
    }
    public void _start()
    {
        canWeStart = true;
    }
}
