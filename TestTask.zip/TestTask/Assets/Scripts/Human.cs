﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Human
{
    private int Gold = 0;
    private int Count_Of_Hearts = 50;

    public Human(int Gold, int Count_Of_Hearts)
    {
        this.Gold = Gold;
        this.Count_Of_Hearts = Count_Of_Hearts;
    }

    public int gold
    {
        get
        {
            return Gold;
        }
    }
    public int count_of_hearts
    {
        get
        {
            return Count_Of_Hearts;
        }
    }
    public void SET_GOLD(int _Gold)
    {
       Gold = _Gold;
    }
    public void SET_Health(int _Health)
    {
        Count_Of_Hearts = _Health;
    }
}
