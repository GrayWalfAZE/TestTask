﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeTower : MonoBehaviour
{
    private GameObject Towers_Parent;
    private GameObject[] selectedTowers;
    private GameObject[] Towers;

    private static int k = 0;
    private bool towerUpdated = false;
    public Main m_obj;

    public bool Tower_Updated()
    {
        towerUpdated = true;
        return towerUpdated;
    }
    public void Set_Upgraded()
    {
        towerUpdated = false;
    }
    public void upgradeTowers()
    {
        m_obj = GameObject.FindGameObjectWithTag("GameController").GetComponent<Main>();
        Towers = GameObject.FindGameObjectsWithTag("Tower");

        if (Towers != null)
        {
            for (int i = 0; i < Towers.Length; i++)
            {
                Behaviour halo = (Behaviour)Towers[i].GetComponent("Halo");
                MakeTower make = (MakeTower)Towers[i].GetComponent("MakeTower");
                MouseEventsForTower mouseEvent = (MouseEventsForTower)Towers[i].GetComponent("MouseEventsForTower");
                if (halo.enabled && make.isUpgradeable() && (m_obj.Sent_Coins() >= make.returnUpgradeCost()))
                { 
                    m_obj.decreasseGold(make.returnUpgradeCost());
                    make.upgradeProperities();
                    halo.enabled = false;
                    mouseEvent.costUI.GetComponent<Text>().text = "";
                }
                    
            }
            
        }
    }
}
