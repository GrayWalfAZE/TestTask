﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MouseEventsForTower : MonoBehaviour
{
    private static int _click = 1;

    [SerializeField]
    private Behaviour TBehaviour;

    private GameObject gameManager;
    public Main m_obj;
    public GameObject costUI;

    UpgradeTower upgradeScript = new UpgradeTower();

    private void Start()
    {
        costUI = GameObject.FindGameObjectWithTag("UpgradeCost");
        gameManager = GameObject.FindGameObjectWithTag("GameController");
        m_obj = gameManager.GetComponent<Main>();
        
    }
    void Update()
    {
     //hmm
    }
    public void OnMouseOver()
    {
        costUI = GameObject.FindGameObjectWithTag("UpgradeCost");
        m_obj = GameObject.FindGameObjectWithTag("GameController").GetComponent<Main>(); 
       

        if (Input.GetMouseButtonDown(0) && m_obj.enabled)
        { 
            if (_click == 1) 
            {
                MakeTower makeTower = gameObject.GetComponent<MakeTower>();
                TBehaviour.enabled = true;
                _click = 2;
                costUI.GetComponent<Text>().text = makeTower.returnUpgradeCost().ToString();
            }
            else 
            { 
                TBehaviour.enabled = false;
                _click = 1;
                costUI.GetComponent<Text>().text = "";
            }
        }
        
    }
   
}
