﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class THE_END : MonoBehaviour
{
    [SerializeField]
    GameObject[] For_Enable ;
    [SerializeField]
    private Text END_KilledM_UI;
    [SerializeField]
    private Text END_C_UI;
    [SerializeField]
    private Text END_W_UI;
    [SerializeField]
    private Main m_obj;

    private bool restart=false;

    void Awake()
    {
        END_KilledM_UI.text = m_obj.Sent_DeadEnemies().ToString();
        END_C_UI.text = m_obj.Sent_Coins().ToString();
        END_W_UI.text = m_obj.SentWaveNumber().ToString();
    }

    // Start is called before the first frame update
    void Start()
    {
        END_KilledM_UI.text = "KIlled Enemies: " + m_obj.Sent_DeadEnemies().ToString();
        END_C_UI.text = "Coins: " + m_obj.Sent_Coins().ToString();
        END_W_UI.text = "Wave: " + m_obj.SentWaveNumber().ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (restart)
        {
            foreach (GameObject obj in For_Enable)
            {
                obj.SetActive(true);
            }
        }
    }

    public void Restart_Game()
    {
        m_obj.Get_WaveNum(1);
        restart = true;
        GameObject.FindGameObjectWithTag("Finish").SetActive(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
