﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeEnemy : MonoBehaviour
{
    private int Gold;
    private int Health;
  
    public void Get_Properties(int _gold,int _health)
    {
        Gold = _gold;
        Health = _health;
    }
    public int Return_Health()
    {
        return Health;
    }
    public int Return_Gold()
    {
        return Gold;
    }
    public void Give_Damage_E(int _damage)
    {
        Health -= _damage;
    }
}