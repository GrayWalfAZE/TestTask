﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeTower : MonoBehaviour
{
    private int power;
    private float speed;
    private int upgradeCost;
    private int upgradeNumber;

    public void Get_Properties(int _power, float _speed,int _upgradeCost,int _upgradeNumber)
    {
        power = _power;
        speed = _speed;
        upgradeCost = _upgradeCost;
        upgradeNumber = _upgradeNumber;
    }
    public bool isUpgradeable()
    {
        if (upgradeNumber > 0) return true;
        else return false;
    }
    public void upgradeProperities()
    {
            power++;
            speed++;
            upgradeCost += 50;
            upgradeNumber--;
    }
    public int returnUpgradeCost()
    {
        return upgradeCost;
    }
    public float Return_Tower_Speed()
    {
        return speed;
    }
    public int Return_Tower_Power()
    {
        return power;
    }
}
