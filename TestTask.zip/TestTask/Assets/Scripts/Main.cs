﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Main : MonoBehaviour
{
    [SerializeField]
    private GameObject Enemy_Prefab;
    [SerializeField]
    private Transform Star_Point;
    [SerializeField]
    private GameObject Tower;
    [SerializeField]
    private Transform SpawnPoint_T;
    [SerializeField]
    GameObject[] ForDisable;
    [SerializeField]
    GameObject ForEnable;

    public float Time_Between_Waves = 10f;
    private float countdown = 2f;
    private static int Number_of_Enemies;
    private static int K = 1;
    private static int _Health = 10;
    private int min = 0;
    private int max = 3;
    private static int numberofGold = 0;
    private static int deadEnemies = 0;

    private static Enemy Red_Monster = new Enemy(10,2,1,100f);
    private static WaveFormula wave = new WaveFormula();
    private static Human Player = new Human(0, _Health);
    private UpgradeTower upgradeTower = new UpgradeTower();

    // Start is called before the first frame update
    private void Awake()
    {
        Red_Monster = new Enemy(10, 2, 1, 100f);
        Number_of_Enemies = wave.wave_formula();
        K = wave.wave_number;
        
        numberofGold = 0;
        deadEnemies = 0;
        _Health = 10;

        Player = new Human(0, _Health);

        ForEnable.SetActive(false);

        foreach (GameObject obj in ForDisable)
        {
            obj.SetActive(true);
        }
    }
    void Start()
    {
        Instantiate(Tower, SpawnPoint_T.position, SpawnPoint_T.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        Number_of_Enemies = wave.wave_formula();
        if (Wavefinished()) 
        {
            StartCoroutine(SpawnWave());
            if(wave.wave_number>1)Update_Monster_Prop();
            
        }

        //Finish the game 
        if (Player.count_of_hearts <= 0)
        {
            foreach (GameObject obj in ForDisable)
            {
                obj.SetActive(false);
            }
            findObjectBYTag("Enemy");
            findObjectBYTag("Tower");
            ForEnable.SetActive(true);
        }
      
    }
    public void Get_WaveNum(int _wave)
    {
        wave.wave_number = _wave;
    }
    IEnumerator SpawnWave()
    {
        wave.wave_number = K;
        for (int i = 0; i < Number_of_Enemies; i++)
        {
            SpawnEnemy();
            yield return new WaitForSeconds(80 / Red_Monster.speed);
        }
        K++;
    }
    void SpawnEnemy()
    {
        GameObject Enemy_GO =(GameObject)Instantiate(Enemy_Prefab, Star_Point.position, Star_Point.rotation);
        
        MakeEnemy enemy= Enemy_GO.GetComponent<MakeEnemy>();
        if (enemy != null)
        {
            enemy.Get_Properties(Red_Monster.gold_E,Red_Monster.health_E);
        }
    }
    public void Give_Damage(int _damage)
    {
        _Health -= _damage;
        Player.SET_Health(_Health);
    }
    public int Sent_Health()
    {
        return Player.count_of_hearts;
    }
    private bool Wavefinished()
    {
        return !GameObject.FindGameObjectWithTag("Enemy"); 
    }
    public int SentWaveNumber()
    {
        return wave.wave_number;
    }
    public void Update_Monster_Prop()
    {
        
        Red_Monster.SET_GOLD(Red_Monster.gold_E + Random.Range(min, max));
        Red_Monster.SET_Health(Red_Monster.health_E + Random.Range(min, max));
        Red_Monster.damage_to_tower += Random.Range(min, max);
        Red_Monster.speed += Random.Range(min, max); ;
       
    }
    public float Return_Speed()
    {
        return Red_Monster.speed;
    }
    public int Return_Damage()
    {
        return Red_Monster.damage_to_tower;
    }
    public void increase_Poits(int _totalgold,int _totaldeath)
    {
        numberofGold += _totalgold;
        deadEnemies += _totaldeath;
       
    }
    public int Sent_Coins()
    {
        return numberofGold;
    }
    public int Sent_DeadEnemies()
    {
        return deadEnemies;
    }
    public void findObjectBYTag(string _name)
    {
        GameObject[] searchedObjects = GameObject.FindGameObjectsWithTag(_name);
        foreach(GameObject obj in searchedObjects)
        {
            obj.SetActive(false);
        }
    }
    public void decreasseGold(int _upgradeCost)
    {
        numberofGold -= _upgradeCost;
    }
}
