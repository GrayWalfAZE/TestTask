﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Main))]
[RequireComponent(typeof(GameObject))]

public class EnemyMovement : MonoBehaviour
{
   
    public Collider col;
    private Transform target;
    private int CurrentPlace=0;
    [SerializeField]
    private GameObject Enemy_object;
    [SerializeField]
    private Transform G_Manager;
    [SerializeField]
    private Main m_obj = new Main();
    
    // Start is called before the first frame update
    void Awake()
    {
       m_obj = G_Manager.GetComponent<Main>();   
    }
    void Start()
    {
       target = Way.points[CurrentPlace];
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 direction = target.position - transform.position;

        transform.Translate(direction.normalized * m_obj.Return_Speed() * Time.deltaTime, Space.World);

        if (Vector3.Distance(transform.position,target.position)<=1f && CurrentPlace < Way.points.Length - 1) 
        { 
            CurrentPlace++; target = Way.points[CurrentPlace]; 
        }

    }

    void OnCollisionEnter(Collision collide)
    {
        if (collide.collider.gameObject.name == "Tower")
        {
            Destroy(Enemy_object);
            m_obj.Give_Damage(m_obj.Return_Damage());
        }
    }
}
