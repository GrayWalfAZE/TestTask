﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChooseSellected : MonoBehaviour
{
    private int Count_Of_Child;
    public static Transform[] points;
    private void Awake()
    {
        Count_Of_Child = transform.childCount;
        points = new Transform[transform.childCount];
        for (int i = 0; i < points.Length; i++)
        {
            points[i] = transform.GetChild(i);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public Transform[] Points()
    {
        int k = 0;
        Transform[] SellectedPoints = new Transform[points.Length]; ;
        for (int i = 0; i < points.Length; i++)
        {
            Behaviour halo = (Behaviour)points[i].GetComponent("Halo");
            if (halo.enabled)
            SellectedPoints[k] = points[i];
        }
        return SellectedPoints;
    }
}
