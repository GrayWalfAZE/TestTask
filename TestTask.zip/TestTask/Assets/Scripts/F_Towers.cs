﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class F_Towers
{
    private int Power_Of_Fire = 1;
    private float Speed_Of_Fire = 2f;
    private int Upgrade_Cost = 50;
    private int Numbers_Of_Upgrades = 10;
    public int power
    {
        get 
        {
            return Power_Of_Fire; 
        }
    }
    public float speed
    {
        get
        {
            return Speed_Of_Fire;
        }    
    }
    public int upgradeCost
    {
        get
        {
            return Upgrade_Cost;
        }
    }
    public int numbers_Of_Upgrades
    {
        get
        {
            return Numbers_Of_Upgrades;
        }
    }
}
