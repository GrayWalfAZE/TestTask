﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Human
{
    private int Damage_To_Tower = 1;
    private float Speed = 100f;
    
    public Enemy(int gold, int count_of_hearts, int Damage_To_Tower, float Speed) : base(gold, count_of_hearts)
    {
        this.Damage_To_Tower = Damage_To_Tower;
        this.Speed = Speed;
        
    }
    public int damage_to_tower
    {
        get
        {
            return Damage_To_Tower;
        }
        set
        {
            Damage_To_Tower = value;
        }
    }
    public float speed
    {
        get
        {
            return Speed;
        }
        set
        {
            Speed = value;
        }
    }
    public int gold_E
    {
        get
        {
            return this.gold;
        }
        set
        {
            this.SET_GOLD(value);
        }
    }
    public int health_E
    {
        get
        {
            return this.count_of_hearts;
        }
        set
        {
            this.SET_Health(value);
        }
    } 
    

    
}
