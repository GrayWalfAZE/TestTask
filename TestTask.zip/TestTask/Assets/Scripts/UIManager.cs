﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(Text))]
[RequireComponent(typeof(Main))]

public class UIManager : MonoBehaviour
{   
    [SerializeField]
    private Text H_UI;
    [SerializeField]
    private Text C_UI;
    [SerializeField]
    private Text W_UI;
    [SerializeField]
    private Main m_obj;
   
    // Start is called before the first frame update
    void Start()
    {
        m_obj = GetComponent<Main>();
       
        C_UI.text = "Coins: " + m_obj.Sent_Coins().ToString(); 
        W_UI.text = "Wave: " + m_obj.SentWaveNumber().ToString();
        H_UI.text = "Hearts: " + m_obj.Sent_Health().ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (m_obj.Sent_Health() > 0) H_UI.text = "Hearts: " + m_obj.Sent_Health().ToString();
        else H_UI.text = "Hearts: 0";
        
        W_UI.text = "Wave: " + m_obj.SentWaveNumber().ToString();
        C_UI.text = "Coins: " + m_obj.Sent_Coins().ToString();
        
    }
}
