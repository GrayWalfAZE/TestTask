﻿/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CreateEnemy : MonoBehaviour
{
    private static int _Gold;
    private static int _Health;
    private static int _Damage;
    private static float _Speed;

    MakeEnemy make_obj = new MakeEnemy();

    private void Awake()
    {
        _Gold = make_obj.Return_Gold();
        _Health = make_obj.Return_Health();
        _Damage = make_obj.Return_Damage();
        _Speed = make_obj.Return_Speed();
    }
   
    void Update()
    {
        Debug.Log("_Gold: " + _Gold);
        Debug.Log("_Health: " + _Health);
        Debug.Log("_Damage: " + _Damage);
        Debug.Log("speed: " + _Speed);
        make_obj.Update_Enemy_P(_Gold, _Health, _Damage, _Speed);
        
       
    }
    public float Return_Speed()
    {
        return _Speed;
    }
    public int Return_Health()
    {
        return _Health;
    }
    public int Return_Damage()
    {
        return _Damage;
    }
    public int Return_Gold()
    {
        return _Gold;
    }
    public void Get_Gold(int Gold)
    {

        _Gold+= Gold;
    }
    public void Get_Health(int Health)
    {

        _Health += Health;
    }
    public void Get_Damage(int Damage)
    {

         _Damage += Damage;
    }
    public void Get_Speed(float Speed)
    {

          _Speed += Speed;
    }
    public void Give_Damage(int _damage)
    {
        _Health -= _damage;
    }
}
*/