﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    private GameObject target;
    private float speedofBullet = 400f;
    private int bulletDamage = 1;
    private static MakeEnemy enemy_obj;
    private Main m_obj = new Main();
   
    public void Get_Target(GameObject _target,int _bulletDamage)
    {
        target = _target;
        bulletDamage = _bulletDamage;
    }
    void Update()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }
        
        Vector3 direction = target.transform.position - transform.position;
        float distanceThisFrame = speedofBullet * Time.deltaTime;

        if (direction.magnitude <= distanceThisFrame)
        { 
            enemy_obj = target.GetComponent<MakeEnemy>();
            HitTarget();
            return;
        }
        transform.Translate(direction.normalized* distanceThisFrame, Space.World);  
    }
    public void HitTarget()
    {
        if (enemy_obj.Return_Health() > 0)
        {
            enemy_obj.Give_Damage_E(bulletDamage);
            Destroy(gameObject);
            return;
        }
        else
        {
            m_obj.increase_Poits(enemy_obj.Return_Gold(), 1);
            Destroy(target);
            Destroy(gameObject);
            return;
        }
        
    }
    
}
