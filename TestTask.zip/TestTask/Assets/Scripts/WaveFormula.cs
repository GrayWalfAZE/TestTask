﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveFormula
{
    private int K = 1;
    public int wave_number
    {
        get
        {
            return K;
        }
        set
        {
            K = value;
        }
        
    }
    public int wave_formula()
    {
        return (K + 10);
    }
    
}
