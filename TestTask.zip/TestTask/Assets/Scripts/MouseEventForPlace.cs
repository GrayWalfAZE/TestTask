﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseEventForPlace : MonoBehaviour
{
    private  bool _UNclick = true;
    Vector3 v3 = new Vector3(-2, -2, -2);
    private bool _placed = false;

    private Renderer rendereR;
    private Color StartColor;

    private Transform T_place;
    private GameObject Towers_Parent;

    [SerializeField]
    private Color HoverColor;
    [SerializeField]
    private GameObject Tower;
    
    private static F_Towers fireTower = new F_Towers();

    private void Start()
    {
        rendereR = GetComponent<Renderer>();
        StartColor = rendereR.material.color;
        Towers_Parent = GameObject.FindGameObjectWithTag("Towers_Parent");
    }

    public void OnMouseDown()
    {
        GameObject gm = GameObject.FindGameObjectWithTag("GameController");
        if (_placed) return;
        else if( gm == null )
        {
            GameObject towerOG=(GameObject)Instantiate(Tower, transform.position + v3, Tower.transform.rotation);
            MakeTower makeTower = towerOG.GetComponent<MakeTower>();
            makeTower.Get_Properties(fireTower.power, fireTower.speed, fireTower.upgradeCost, fireTower.numbers_Of_Upgrades);
            _placed = true;
            towerOG.transform.parent = Towers_Parent.transform;
        }
    }
    public void OnMouseEnter()
    {
       if(!_placed) rendereR.material.color = HoverColor;
    }
    public void OnMouseExit()
    {
        rendereR.material.color = StartColor;
    }
    
}
